RobotPy WPILib
==============

Python version of WPILib - the standard library used for programming FRC
robots.

Installation
============

Typically, you don't install this directly, but use the RobotPy installer
to install it on your roboRIO, or it is installed by pip as part of the
pyfrc setup process.
